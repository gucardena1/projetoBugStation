from flask import Flask, render_template, request, redirect, url_for
import csv
from datetime import datetime

app = Flask(__name__)

ARQUIVO = "bugs.csv"
CAMPOS = ["id", "data", "descricao", "passos", "esperado", "obtido", "ambiente", "gravidade", "status", "responsavel"]

def carregar_bugs():
    try:
        with open(ARQUIVO, newline='', encoding='utf-8') as f:
            return list(csv.DictReader(f))
    except FileNotFoundError:
        return []

def salvar_bugs(bugs):
    with open(ARQUIVO, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=CAMPOS)
        writer.writeheader()
        writer.writerows(bugs)

@app.route("/")
def index():
    bugs = carregar_bugs()
    return render_template("index.html", bugs=bugs)

@app.route("/adicionar", methods=["GET", "POST"])
def adicionar():
    if request.method == "POST":
        bugs = carregar_bugs()
        novo_bug = {
            "id": str(len(bugs) + 1),
            "data": datetime.now().strftime('%d/%m/%Y'),
            "descricao": request.form["descricao"],
            "passos": request.form["passos"],
            "esperado": request.form["esperado"],
            "obtido": request.form["obtido"],
            "ambiente": request.form["ambiente"],
            "gravidade": request.form["gravidade"],
            "status": "Novo",
            "responsavel": request.form["responsavel"],
        }
        bugs.append(novo_bug)
        salvar_bugs(bugs)
        return redirect(url_for("index"))
    return render_template("adc.html")

@app.route("/atualizar/<id>", methods=["GET", "POST"])
def atualizar(id):
    bugs = carregar_bugs()
    bug = next((b for b in bugs if b["id"] == id), None)
    if not bug:
        return "Bug não encontrado", 404

    if request.method == "POST":
        bug["status"] = request.form["status"]
        salvar_bugs(bugs)
        return redirect(url_for("index"))

    return render_template("atualizar.html", bug=bug)

if __name__ == "__main__":
    app.run(debug=True)
